-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 07-07-2024 a las 05:07:30
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `corven_test`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalog_relation_type`
--

CREATE TABLE `catalog_relation_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `catalog_relation_type`
--

INSERT INTO `catalog_relation_type` (`id`, `name`) VALUES
(1, 'HERMAN@'),
(2, 'PRIM@'),
(3, 'TI@');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person`
--

CREATE TABLE `person` (
  `id` bigint(20) NOT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `document_number` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `born_date` varchar(255) DEFAULT NULL,
  `insert_date` datetime DEFAULT current_timestamp(),
  `document_nmumber` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `person`
--

INSERT INTO `person` (`id`, `document_type`, `document_number`, `country_code`, `gender`, `name`, `last_name`, `email`, `born_date`, `insert_date`, `document_nmumber`) VALUES
(353, 'DNI', '27434786', 'AR', 'M', 'Leandro', 'mourino', 'lmourio@gmail.com', '1979-12-11', '2024-07-04 12:45:17', NULL),
(402, 'DNI', '30397352', 'PY', 'F', 'Laura', 'Peña', 'larape@gmail.com', '1983-07-14', '2024-07-05 10:36:28', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person_relation`
--

CREATE TABLE `person_relation` (
  `id` bigint(20) NOT NULL,
  `person_parent_id` bigint(20) DEFAULT NULL,
  `person_id` bigint(20) DEFAULT NULL,
  `relation_type_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `person_relation`
--

INSERT INTO `person_relation` (`id`, `person_parent_id`, `person_id`, `relation_type_id`) VALUES
(1, 353, 402, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person_relation_seq`
--

CREATE TABLE `person_relation_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `person_relation_seq`
--

INSERT INTO `person_relation_seq` (`next_val`) VALUES
(101);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person_seq`
--

CREATE TABLE `person_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `person_seq`
--

INSERT INTO `person_seq` (`next_val`) VALUES
(551);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `catalog_relation_type`
--
ALTER TABLE `catalog_relation_type`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_unique_person` (`document_type`,`document_number`,`country_code`,`gender`) USING HASH;

--
-- Indices de la tabla `person_relation`
--
ALTER TABLE `person_relation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relation_type_id` (`relation_type_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `catalog_relation_type`
--
ALTER TABLE `catalog_relation_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `person_relation`
--
ALTER TABLE `person_relation`
  ADD CONSTRAINT `person_relation_ibfk_1` FOREIGN KEY (`relation_type_id`) REFERENCES `catalog_relation_type` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
